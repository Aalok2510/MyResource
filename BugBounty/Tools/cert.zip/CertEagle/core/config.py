# Those are fake "BOT_TOKEN" and "GROUP_ID" values
# You need to change those values and rename the file to 'config.py'
BOT_TOKEN ="1302168418:AAHMkw35nwkCaccAPq80roYFZaPgvehSr2g"
GROUP_ID = "-409412582"
